<?php
    define('BASE_URL', 'http://localhost/2026BSIT2DGROUP4/BuligDiretso/');

    define('VIEW_PATH', __DIR__ . '/../views/');
    define('CONTROLLER_PATH', __DIR__ . '/../controllers/');
    define('MODEL_PATH', __DIR__ . '/../models/');
    define('ASSETS_PATH', BASE_URL . 'assets/');
?>